//+build !gccgo

package depBase

func ImplementedInAsm()
